<html>
<body>
<?php if(isset($_POST['cal'])&&isset($_POST['num1'])&&isset($_POST['num2'])): ?>
<?php 
$cal=$_POST['cal'];
$num1=$_POST['num1'];
$num2=$_POST['num2'];

switch($cal) {
    case '+':
        echo "Answer: ". $num1+$num2;
        break;
    case '-':
        echo "Answer: ". $num1-$num2;
        break;
    case '*':
        echo "Answer: ". $num1*$num2;
        break;
    case '/':
        echo "Answer: ". $num1/$num2;
        break;
    case '^':
        $ans=$num1;
        if($num2==0) {echo "Answer: ". 1; break;}

        for ($i=1; $i<$num2; $i++) {
            $ans=$ans*$num1;
        }

        echo "Answer: ". $ans;
        break;
    default:
        echo "Answer: ". 1/$num1;
        break;
}


?>
<?php endif; ?>

</body>
</html>