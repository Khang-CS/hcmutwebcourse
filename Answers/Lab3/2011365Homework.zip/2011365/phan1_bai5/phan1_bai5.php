<html>
<body>

<form action="method.php" method="post">
Enter calculation: <input type="text" name="num1">
  <select id="cal" name="cal">
    <option value="+">+</option>
    <option value="-">-</option>
    <option value="*">*</option>
    <option value="/">/</option>
    <option value="%">%</option>
    <option value="^">^</option>
    <option value="^-1">^-1</option>
  </select>
  <input type="text" name="num2">
<input type="submit">
</form>

</body>
</html>