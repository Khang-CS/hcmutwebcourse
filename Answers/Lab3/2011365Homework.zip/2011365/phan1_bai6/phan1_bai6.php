<html>
<body>

<form action="welcome.php" method="post">
First name: <input type="text" name="firstName"><br>
Last name: <input type="text" name="lastName"><br>
E-mail: <input type="text" name="email"><br>
Password: <input type="password" name="pass"><br>
<label for="birthday">Birthday:</label>

<select name="day" id="day">
    <option value=1>1</option>
    <option value=1>2</option>
    <option value=1>3</option>
    <option value=1>4</option>
    <option value=1>5</option>
    <option value=1>6</option>
    <option value=1>7</option>
    <option value=1>8</option>
    <option value=1>9</option>
    <option value=1>10</option>
    <option value=1>11</option>
    <option value=1>12</option>
    <option value=1>13</option>
    <option value=1>14</option>
    <option value=1>15</option>
    <option value=1>16</option>
    <option value=1>17</option>
    <option value=1>18</option>
    <option value=1>19</option>
    <option value=1>20</option>
    <option value=1>21</option>
    <option value=1>22</option>
    <option value=1>23</option>
    <option value=1>24</option>
    <option value=1>25</option>
    <option value=1>26</option>
    <option value=1>27</option>
    <option value=1>28</option>
    <option value=1>29</option>
    <option value=1>30</option>
    <option value=1>31</option>
</select>

<select name="month" id="month">
    <option value=1>1</option>
    <option value=1>2</option>
    <option value=1>3</option>
    <option value=1>4</option>
    <option value=1>5</option>
    <option value=1>6</option>
    <option value=1>7</option>
    <option value=1>8</option>
    <option value=1>9</option>
    <option value=1>10</option>
    <option value=1>11</option>
    <option value=1>12</option>
</select>

<select name="year" id="year">
    <option value=1>1989</option>
    <option value=1>1990</option>
    <option value=1>1991</option>
    <option value=1>1992</option>
    <option value=1>1993</option>
    <option value=1>1994</option>
    <option value=1>1995</option>
    <option value=1>1996</option>
    <option value=1>1997</option>
    <option value=1>1998</option>
    <option value=1>1999</option>
    <option value=1>2000</option>
    <option value=1>2001</option>
    <option value=1>2002</option>
    <option value=1>2003</option>
    <option value=1>2004</option>
    <option value=1>2005</option>
    <option value=1>2006</option>
    <option value=1>2007</option>
    <option value=1>2008</option>
    <option value=1>2009</option>
    <option value=1>2010</option>
    <option value=1>2011</option>
    <option value=1>2012</option>
    <option value=1>2013</option>
    <option value=1>2014</option>
    <option value=1>2015</option>
    <option value=1>2016</option>
    <option value=1>2017</option>
    <option value=1>2018</option>
    <option value=1>2019</option>
    <option value=1>2020</option>
    <option value=1>2021</option>
    <option value=1>2022</option>
</select>
<br>
Gender: 
<input type="radio" id="male" name="gender" value="Male">
<label for="male">Male</label>
<input type="radio" id="female" name="gender" value="Female">
<label for="female">Female</label>
<input type="radio" id="unknown" name="gender" value="Unknown">
<label for="unknown">Unknown</label>
<br>

<label for="country">Country:</label>
<select name="contry" id="country">
    <option value="Vietnam">Vietnam</option>
    <option value="Australia">Australia</option>
    <option value="United States">United States</option>
    <option value="India">India</option>
    <option value="Other">Other</option>
</select>
<br>

<textarea rows="4" cols="50" maxlength="10000">
Enter text here...</textarea>
<br>

<input type="submit">
<br>
<input type=reset name="r" value="reset">
</form>


</body>
</html>