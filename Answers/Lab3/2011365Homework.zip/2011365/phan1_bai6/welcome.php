<html>
<body>

<?php
$firstName=$_POST["firstName"];
$firstNameLen=strlen($firstName);
if($firstNameLen>30) {
    $message = "Your first name is too long !";
echo $message."<br>";
}
if($firstNameLen<2) {
    echo "Your first name is too short !"."<br>";
}

$lastName=$_POST["lastName"];
$lastNameLen=strlen($lastName);
if($lastNameLen>30) {
    echo "Your last name is too long !"."<br>";
}
if($lastNameLen<2) {
    echo "Your last name is too short !"."<br>";
}

$pass=$_POST["pass"];
$passLen=strlen($pass);
if($passLen<2) {
    echo "Your password is too short !"."<br>";
}
if($passLen>30) {
    echo "Your password is too long !"."<br>";
}

if(!isset($_POST["gender"])) {
    echo "You did not choose gender, please go back !"."<br>";
}

echo "<h3>Complete !</h3>"."<br>"


?>

<button type="button" onclick="history.back();">Back</button>
</body>
</html>