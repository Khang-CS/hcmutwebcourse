<?php
require_once('php/init.php');
$cars = getCars();
  
  // Thêm Car vào bảng Cars
  $check = true;
  if(isset($_POST['btnOk'])) {
    $check = true;
    $id = $_POST['id'];
    $name = $_POST['name'];
    $year = $_POST['year'];
	  $pattern1 = "/^[0-9]+$/i";
    if(preg_match($pattern1, $id) && strlen($name) >= 5 && strlen($name) <= 40 && preg_match($pattern1, $year) && $year >= 1990 && $year <= 2022) {
	    addCar($id, $name, $year);
	    header("Location: a.php");
    }
    else $check = false;
  }

  ?>