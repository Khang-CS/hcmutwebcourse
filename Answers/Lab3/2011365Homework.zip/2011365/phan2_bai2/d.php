<?php

require_once('php/init.php');
if(isset($_POST['btnDel'])) {
    $id = $_POST['car_id'];
    deleteCar($id);
	  header("Location: a.php");
  }

  ?>