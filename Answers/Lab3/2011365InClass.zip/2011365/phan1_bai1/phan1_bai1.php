<!DOCTYPE html>
<html>
<body>

<?php
$x=10;
$y=7;

echo $x . " + " .$y ." = ". $x+$y."<br>"; 
echo $x . " - " .$y ." = ". $x-$y."<br>";
echo $x . " * " .$y ." = ". $x*$y."<br>";
echo $x . " / " .$y ." = ". $x/$y."<br>";
echo $x . " % " .$y ." = ". $x%$y."<br>";    
?>

</body>
</html>