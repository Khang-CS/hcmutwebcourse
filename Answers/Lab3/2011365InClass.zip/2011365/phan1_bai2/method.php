<html>
<body>
<?php if(isset($_POST['number'])): ?>
<?php 
$num=$_POST['number'];
$express=$num%5;
switch($express) {
    case 0:
     echo "Hello";
     break;
    case 1:
     echo "How are you ?";
     break;
    case 2:
     echo "I'm doing well, thank you";
     break;
    case 3:
     echo "See you later";
     break;
    default:
     echo "Good-bye";
     break;
}

?>
<?php endif; ?>

</body>
</html>