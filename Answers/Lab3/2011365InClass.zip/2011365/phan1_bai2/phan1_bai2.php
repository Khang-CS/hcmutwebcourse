<html>
<body>

<form action="method.php" method="post">
Enter number: <input type="text" name="number"><br>
<input type="submit">
</form>

</body>
</html>