<html>
    <body>
        <?php 
        echo "<h3>"."For loop"."</h3>"."<br>";

        $y =0;
        for ($i=0; $i<101; $i++) {
            if($i%2!=0) echo $i . " ";
        }
        echo "<br>";

        echo "<h3>"."While loop"."</h3>"."<br>";
        
        while($y!=101) {
            if($y%2!=0) echo $y." ";
            $y++;
        }

        ?>
</body>
</html>