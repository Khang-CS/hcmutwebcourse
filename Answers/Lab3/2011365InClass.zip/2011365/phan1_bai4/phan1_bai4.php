<html>
	<head>
		<style>
			table {
  border: 1px solid black;
  table-layout: fixed;
  width: 200px;
  text-align: center;
  background-color: yellow;
  border-collapse: collapse;
}

th,
td {
  border: 1px solid black;
  width: 30px;
  overflow: hidden;
}
			</style>
</head>
    <body>
    <?php
echo "<table>";
	for ($row=1; $row <= 10; $row++) { 
		echo "<tr> \n";
		for ($col=1; $col <= 10; $col++) { 
		   $p = $col * $row;
		   echo "<td>$p</td> \n";
		   	}
	  	    echo "</tr>";
		}
		echo "</table>";
?>

</body>
    </html>
