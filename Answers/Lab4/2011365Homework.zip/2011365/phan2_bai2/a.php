<?php
// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

include_once './database.php';
include_once './Cars.php';

// Instantiate DB & connect
$database = new Database();
$db = $database->connect();

// Instantiate blog cars object
$cars = new Cars($db);

// Blog cars query
$result = $cars->read();
// Get row count
$num = $result->rowCount();

// Check if any car
if ($num > 0) {
  // Cars array
  $cars_arr = array();

  while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
    extract($row);

    $cars_item = array(
      'id' => $id,
      'name' => $name,
      'year' => $year
    );

    array_push($cars_arr, $cars_item);
  }

  // Turn to JSON & output
  echo json_encode($cars_arr);
} else {
  // No Car
  echo json_encode(
    array('message' => 'No Car Found')
  );
}
