// Function to turn url to an object
function getUrlObj(url) {
  let hash;
  let myJson = {};
  let hashes = url.slice(url.indexOf('?') + 1).split('&');
  for (let i = 0; i < hashes.length; i++) {
    hash = hashes[i].split('=');
    myJson[hash[0]] = hash[1];
  }
  return JSON.stringify(myJson);
}

// Function to validate inputs
function validateInputs(id, name, year) {
  let flag = true;
  try {
    let validateYear = Number(year);
  } catch (e) {
    flag = false;
    window.alert('Year: Integer between 1990 and 2015');
  }
  if (!Number(id)) {
    flag = false;
    window.alert('ID: Must be integer');
  }
  if (name.length < 5 || name.length > 40) {
    flag = false;
    window.alert('Name: Length from 5 to 40.');
  }
  if (year < 1990 || year > 2015 || isNaN(year)) {
    flag = false;
    window.alert('Year: Integer between 1990 and 2015');
  }
  return flag;
}

//GET REQUEST
$(document).ready(function () {
  $('#showTable').click(function () {
    $.getJSON('http://localhost/a.php', function (data) {
      let cars_data = '';
      $.each(data, function (key, value) {
        cars_data += '<tr>';
        cars_data += '<td>' + value.id + '</td>';
        cars_data += '<td>' + value.name + '</td>';
        cars_data += '<td>' + value.year + '</td>';
        cars_data +=
          '<td>' +
          '<a type="button" class="btn btn-danger del-btn" >Delete</a>' +
          ' ' +
          '<button type="button" class="btn btn-primary edit-btn" data-id="' +
          value.id +
          '" data-name="' +
          value.name +
          '" data-year="' +
          value.year +
          '">Edit</button>' +
          '</td>';
        cars_data += '</tr>';
      });
      $('#table').append(cars_data);
      $('#showTable').hide();
    });
  });
});

$(document).on('click', '.edit-btn', function () {
  $('#update-btn').show();
  $('#add-btn').hide();
  $('#backToAdd').show();
  $('#id').val($(this).data('id'));
  $('#name').val($(this).data('name'));
  $('#year').val($(this).data('year'));
});

$(document).ready(function () {
  $('#add-btn').click(function (e) {
    e.preventDefault();
    let id = document.getElementById('id').value;
    let name = document.getElementById('name').value;
    let year = document.getElementById('year').value;

    if (validateInputs(id, name, year)) {
      // Serialize form data
      let url = $('#form').serialize();

      // Pass serialized data to function
      let test = getUrlObj(url);

      // Post with ajax
      $.ajax({
        type: 'POST',
        url: 'http://localhost/b.php',
        data: test,
        ContentType: 'application/json',

        success: function () {
          var cars_data = '';
          cars_data += '<tr>';
          cars_data += '<td>' + id + '</td>';
          cars_data += '<td>' + name + '</td>';
          cars_data += '<td>' + year + '</td>';
          cars_data +=
            '<td>' +
            '<a type="button" class="btn btn-danger del-btn" >Delete</a>' +
            ' ' +
            '<button type="button" class="btn btn-primary edit-btn" data-id="' +
            id +
            '" data-name="' +
            name +
            '" data-year="' +
            year +
            '">Edit</button>' +
            '</td>';
          cars_data += '</tr>';
          alert('Add successful!');
          $('#table').prepend(cars_data);
        },
        error: function () {
          alert('Add failed!');
        },
      });
    }
  });
});

$(document).on('click', '#backToAdd', function () {
  $('#update-btn').hide();
  $('#add-btn').show();
  $('#backToAdd').hide();
  $('#form').trigger('reset');
});

$(document).ready(function () {
  $('#update-btn').click(function (e) {
    e.preventDefault();
    let id = document.getElementById('id').value;
    let name = document.getElementById('name').value;
    let year = document.getElementById('year').value;

    if (validateInputs(id, name, year)) {
      // Serialize form data
      let url = $('#form').serialize();

      // Pass serialized data to function
      let test = getUrlObj(url);

      // Post with ajax
      $.ajax({
        type: 'PUT',
        url: 'http://localhost/c.php',
        data: test,
        ContentType: 'application/json',

        success: function () {
          let cars_data = '';
          cars_data += '<tr>';
          cars_data += '<td>' + id + '</td>';
          cars_data += '<td>' + name + '</td>';
          cars_data += '<td>' + year + '</td>';
          cars_data +=
            '<td>' +
            '<a type="button" class="btn btn-danger del-btn" >Delete</a>' +
            ' ' +
            '<button type="button" class="btn btn-primary edit-btn" data-id="' +
            id +
            '" data-name="' +
            name +
            '" data-year="' +
            year +
            '">Edit</button>' +
            '</td>';
          cars_data += '</tr>';
          alert('Update successful!');
          $('.edit-btn[data-id=' + id + ']')
            .parent()
            .parent()
            .remove();
          $('#table').prepend(cars_data);
        },
        error: function () {
          alert('Update failed!');
        },
      });
      $('#update-btn').hide();
      $('#add-btn').show();
      $('#backToAdd').hide();
      $('#form').trigger('reset');
    }
  });
});

$(document).on('click', '.del-btn', function () {
  let idDel = $(this).siblings('.edit-btn').data('id');

  let obj = { id: idDel };

  // Pass serialized data to function
  let test = JSON.stringify(obj);

  // Post with ajax
  $.ajax({
    type: 'DELETE',
    url: 'http://localhost/d.php',
    data: test,
    ContentType: 'application/json',

    success: function () {
      alert('Delete successful!');
      $('.edit-btn[data-id=' + idDel + ']')
        .parent()
        .parent()
        .remove();
    },
    error: function () {
      alert('Delete failed!');
    },
  });
});
