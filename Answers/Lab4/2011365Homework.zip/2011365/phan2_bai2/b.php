<?php
// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once './database.php';
include_once './Cars.php';

// Instantiate DB & connect
$database = new Database();
$db = $database->connect();

// Instantiate blog cars object
$cars = new Cars($db);

// Get raw cars data
$data = json_decode(file_get_contents("php://input"));

$cars->id = $data->id;
$cars->name = $data->name;
$cars->year = $data->year;

// Create car
if ($cars->create()) {
  echo json_encode(
    array('message' => 'Car Created')
  );
} else {
  echo json_encode(
    array('message' => 'Car Not Created')
  );
}
