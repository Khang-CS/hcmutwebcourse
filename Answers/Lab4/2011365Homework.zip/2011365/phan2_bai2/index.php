<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Lab 4</title>

</head>

<body>
    <div class="container">
        <h1>Phan 2 - Bai 2</h1>
        <div class="row">
            <form id="form" style="width: 35%;">
                <div class="mb-1">
                    <input type="text" class="form-control" id="id" name="id" placeholder="ID">
                </div>
                <div class="mb-1">
                    <input type="text" class="form-control" id="name" name="name" value="" placeholder="Name">
                </div>
                <div class="mb-1">
                    <input type="text" class="form-control" id="year" name="year" value="" placeholder="Year">
                </div>
                <button id='add-btn' type="submit" name="submit" class="btn btn-primary">Add new car</button>
                <button id='update-btn' type="submit" name="update" class="btn btn-warning" style="display: none;">Update</button>
                <button type="reset" class="btn btn-success">Reset</button>
                <button id="backToAdd" class="btn btn-success" style="display: none;">Back to Add</button>
            </form>
            <table class="table table-success table-striped mt-5">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Year</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="table">
                </tbody>
            </table>
            <div class="d-flex justify-content-center">
                <button id="showTable" class="btn btn-info">Show Table</button>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="ajaxCall.js"></script>
</body>

</html>