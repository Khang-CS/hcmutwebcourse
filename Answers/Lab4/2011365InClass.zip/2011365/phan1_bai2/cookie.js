const addCookie = document.querySelector('#add-cookie');
const form = document.querySelector('form');
const cookies = document.cookie.split(';');
console.log(cookies.length);

if (cookies.length > 0) {
  const ul = document.createElement('ul');
  for (let cookie of cookies) {
    if (cookie) {
      let li = document.createElement('li');
      let btn1 = document.createElement('button');
      btn1.innerText = 'Delete';
      let btn2 = document.createElement('button');
      btn2.innerText = 'Update';
      li.append(btn1);
      li.append(btn2);
      li.append(cookie.trim().replace('=', ' = '));
      ul.appendChild(li);
      document.body.appendChild(ul);
    }
  }
}

const lis = document.querySelectorAll('li');
if (lis.length > 0) {
  for (let li of lis) {
    li.children[0].addEventListener('click', (e) => {
      const name = e.target.parentElement.innerText
        .split(' = ')[0]
        .replace('DeleteUpdate', '');
      document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC;`;
      location.reload();
    });
    li.children[1].addEventListener('click', (e) => {
      const h1 = document.querySelector('h1');
      h1.innerText = 'Update Cookie:';
      const name = e.target.parentElement.innerText
        .split(' = ')[0]
        .replace('DeleteUpdate', '');
      form.elements[(id = 'name')].value = name;
      form.elements[(id = 'name')].disabled = true;
    });
  }
}

addCookie.addEventListener('click', (e) => {
  document.cookie =
    form.elements[(id = 'name')].value +
    '=' +
    form.elements[(id = 'value')].value;
});
