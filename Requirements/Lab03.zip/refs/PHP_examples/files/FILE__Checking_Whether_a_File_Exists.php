<?
    if (file_exists("snapshot1.png")) {
            print "Snapshot1.png exists!\n";
    } else {
            print "Snapshot1.png does not exist!\n";
    }
?>