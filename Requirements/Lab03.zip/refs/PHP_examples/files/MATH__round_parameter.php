<?php
    $ceil_number = ceil(11.9); // 12
	$floor_number = floor(11.9);
	
	echo $ceil_number."<br  />".$floor_number;
?>